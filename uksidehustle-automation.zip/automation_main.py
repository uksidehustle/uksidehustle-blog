#!/usr/bin/env python3
"""
MAIN AUTOMATION SCRIPT - UK Side Hustle Automation System
Runs all automated money-making processes
"""

import os
import sys
import json
import time
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AutomationSystem:
    """Main automation system controller"""
    
    def __init__(self):
        self.start_time = datetime.now()
        self.earnings = 0.0
        self.status = "initializing"
        self.components = {}
        
        # Load configuration
        self.config = self.load_config()
        
        # Initialize components
        self.init_components()
        
    def load_config(self) -> Dict[str, Any]:
        """Load system configuration"""
        config = {
            "owner": {
                "name": "Hussain",
                "email": "uksidehustle.help@gmail.com",
                "paypal": "hussainhassany2@gmail.com"
            },
            "platforms": {
                "github": "uksidehustle",
                "redbubble": "uksidehustle",
                "teespring": "uksidehustle.creator-spring.com",
                "openai_api_key": os.getenv("OPENAI_API_KEY", ""),
                "canva_pro": True,
                "buffer": True
            },
            "automation": {
                "daily_articles": 2,
                "daily_designs": 10,
                "daily_social_posts": 20,
                "schedule": {
                    "content_generation": "06:00",
                    "publishing": "07:00",
                    "design_creation": "08:00",
                    "design_upload": "09:00",
                    "social_sharing": "10:00",
                    "earnings_check": "11:00",
                    "optimization": "12:00"
                }
            },
            "monitoring": {
                "enabled": True,
                "report_email": "uksidehustle.help@gmail.com",
                "alert_threshold": 0.0  # Alert if earnings drop below
            }
        }
        return config
    
    def init_components(self):
        """Initialize all automation components"""
        logger.info("Initializing automation components...")
        
        # Import and initialize components
        try:
            from content_automation import ContentAutomation
            from design_automation import DesignAutomation
            from social_automation import SocialAutomation
            from monitoring import MonitoringSystem
            
            self.components["content"] = ContentAutomation(self.config)
            self.components["design"] = DesignAutomation(self.config)
            self.components["social"] = SocialAutomation(self.config)
            self.components["monitoring"] = MonitoringSystem(self.config)
            
            logger.info("All components initialized successfully")
            self.status = "ready"
            
        except ImportError as e:
            logger.error(f"Failed to import components: {e}")
            self.status = "error"
            raise
    
    def run_daily_automation(self):
        """Run complete daily automation cycle"""
        logger.info("=" * 60)
        logger.info(f"DAILY AUTOMATION CYCLE - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 60)
        
        daily_report = {
            "date": datetime.now().isoformat(),
            "components": {},
            "earnings": 0.0,
            "status": "running"
        }
        
        # 1. Generate AI Content
        logger.info("Step 1: Generating AI content...")
        try:
            content_result = self.components["content"].generate_daily_content()
            daily_report["components"]["content"] = content_result
            logger.info(f"Content generated: {content_result.get('articles_created', 0)} articles")
        except Exception as e:
            logger.error(f"Content generation failed: {e}")
            daily_report["components"]["content"] = {"error": str(e)}
        
        # 2. Create POD Designs
        logger.info("Step 2: Creating POD designs...")
        try:
            design_result = self.components["design"].create_daily_designs()
            daily_report["components"]["design"] = design_result
            logger.info(f"Designs created: {design_result.get('designs_created', 0)} designs")
        except Exception as e:
            logger.error(f"Design creation failed: {e}")
            daily_report["components"]["design"] = {"error": str(e)}
        
        # 3. Run Social Automation
        logger.info("Step 3: Running social automation...")
        try:
            social_result = self.components["social"].share_daily_content()
            daily_report["components"]["social"] = social_result
            logger.info(f"Social posts: {social_result.get('posts_shared', 0)} posts")
        except Exception as e:
            logger.error(f"Social automation failed: {e}")
            daily_report["components"]["social"] = {"error": str(e)}
        
        # 4. Check Earnings
        logger.info("Step 4: Checking earnings...")
        try:
            earnings_result = self.components["monitoring"].check_earnings()
            daily_earnings = earnings_result.get("daily_earnings", 0.0)
            self.earnings += daily_earnings
            daily_report["earnings"] = daily_earnings
            daily_report["total_earnings"] = self.earnings
            logger.info(f"Daily earnings: £{daily_earnings:.2f}")
            logger.info(f"Total earnings: £{self.earnings:.2f}")
        except Exception as e:
            logger.error(f"Earnings check failed: {e}")
            daily_report["components"]["earnings"] = {"error": str(e)}
        
        # 5. Generate Report
        logger.info("Step 5: Generating daily report...")
        try:
            report_result = self.components["monitoring"].generate_daily_report(daily_report)
            daily_report["report_generated"] = report_result.get("success", False)
            logger.info(f"Report generated: {report_result.get('success', False)}")
        except Exception as e:
            logger.error(f"Report generation failed: {e}")
            daily_report["report_generated"] = False
        
        # 6. System Optimization
        logger.info("Step 6: Running system optimization...")
        try:
            optimization_result = self.components["monitoring"].optimize_system(daily_report)
            daily_report["optimization"] = optimization_result
            logger.info("System optimization completed")
        except Exception as e:
            logger.error(f"Optimization failed: {e}")
            daily_report["optimization"] = {"error": str(e)}
        
        daily_report["status"] = "completed"
        daily_report["completion_time"] = datetime.now().isoformat()
        
        # Save daily report
        self.save_daily_report(daily_report)
        
        logger.info("=" * 60)
        logger.info("DAILY AUTOMATION CYCLE COMPLETED")
        logger.info("=" * 60)
        
        return daily_report
    
    def save_daily_report(self, report: Dict[str, Any]):
        """Save daily report to file"""
        report_dir = "reports"
        os.makedirs(report_dir, exist_ok=True)
        
        filename = f"daily_report_{datetime.now().strftime('%Y%m%d')}.json"
        filepath = os.path.join(report_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"Daily report saved: {filepath}")
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get current system status"""
        status = {
            "system": {
                "status": self.status,
                "start_time": self.start_time.isoformat(),
                "uptime": str(datetime.now() - self.start_time),
                "total_earnings": self.earnings,
                "components_initialized": len(self.components)
            },
            "components": {}
        }
        
        for name, component in self.components.items():
            if hasattr(component, 'get_status'):
                status["components"][name] = component.get_status()
            else:
                status["components"][name] = {"status": "unknown"}
        
        return status
    
    def run_test(self):
        """Run a test of all components"""
        logger.info("Running system test...")
        
        test_results = {}
        
        # Test each component
        for name, component in self.components.items():
            try:
                if hasattr(component, 'test'):
                    result = component.test()
                    test_results[name] = {"status": "passed", "result": result}
                    logger.info(f"Component {name}: PASSED")
                else:
                    test_results[name] = {"status": "no_test_method"}
                    logger.warning(f"Component {name}: No test method")
            except Exception as e:
                test_results[name] = {"status": "failed", "error": str(e)}
                logger.error(f"Component {name}: FAILED - {e}")
        
        # Save test results
        test_file = "system_test_results.json"
        with open(test_file, 'w') as f:
            json.dump(test_results, f, indent=2)
        
        logger.info(f"System test completed. Results saved to {test_file}")
        return test_results

def main():
    """Main function to run the automation system"""
    print("=" * 60)
    print("UK SIDE HUSTLE AUTOMATION SYSTEM")
    print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    try:
        # Initialize system
        print("Initializing automation system...")
        system = AutomationSystem()
        
        # Check system status
        status = system.get_system_status()
        print(f"System Status: {status['system']['status']}")
        print(f"Components Ready: {status['system']['components_initialized']}")
        
        if status['system']['status'] != 'ready':
            print("ERROR: System not ready. Check logs for details.")
            return 1
        
        # Run test first
        print("\nRunning system test...")
        test_results = system.run_test()
        
        # Check if tests passed
        all_passed = all(r.get('status') == 'passed' for r in test_results.values() 
                        if 'status' in r and r['status'] != 'no_test_method')
        
        if not all_passed:
            print("WARNING: Some tests failed. Check test_results.json")
            response = input("Continue with automation anyway? (yes/no): ")
            if response.lower() != 'yes':
                print("Automation cancelled.")
                return 1
        
        # Run daily automation
        print("\n" + "=" * 60)
        print("STARTING DAILY AUTOMATION CYCLE")
        print("=" * 60)
        
        report = system.run_daily_automation()
        
        # Display summary
        print("\n" + "=" * 60)
        print("AUTOMATION SUMMARY")
        print("=" * 60)
        print(f"Date: {report['date']}")
        print(f"Status: {report['status']}")
        print(f"Daily Earnings: £{report.get('earnings', 0):.2f}")
        print(f"Total Earnings: £{report.get('total_earnings', 0):.2f}")
        
        # Component results
        for comp_name, comp_result in report.get('components', {}).items():
            if 'error' in comp_result:
                print(f"{comp_name.upper()}: ERROR - {comp_result['error']}")
            else:
                print(f"{comp_name.upper()}: SUCCESS")
        
        print(f"\nReport saved to: reports/daily_report_*.json")
        print(f"Log file: automation.log")
        
        # Next steps
        print("\n" + "=" * 60)
        print("NEXT STEPS")
        print("=" * 60)
        print("1. Check automation.log for detailed logs")
        print("2. Review daily report in reports/ directory")
        print("3. System will run automatically on schedule")
        print("4. Check email for earnings report")
        
        return 0
        
    except Exception as e:
        logger.error(f"Fatal error in automation system: {e}")
        print(f"ERROR: {e}")
        return 1

if __name__ == "__main__":
    # Set OpenAI API key from environment or config
    if not os.getenv("OPENAI_API_KEY"):
        print("WARNING: OPENAI_API_KEY environment variable not set")
        print("AI content generation will use fallback content")
    
    # Run the system
    exit_code = main()
    sys.exit(exit_code)